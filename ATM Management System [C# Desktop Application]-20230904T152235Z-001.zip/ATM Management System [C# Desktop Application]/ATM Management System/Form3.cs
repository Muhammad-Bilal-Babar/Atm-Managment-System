﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace ATM_Management_System
{
    public partial class Form3 : Form
    {
        public static string type = "";
        MySqlConnection conn = new MySqlConnection("datasource=localhost; port=3306; username=root; password=bilal");
        public Form3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            type = "Current";
            Form4 form = new Form4();
            form.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            type = "Savings";

            //Code to remove
            string sql= "select * from atm.data; update atm.data SET balance = balance - (balance*5/100) where id = '"+ Form1.gval + "'; ";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            //Code to remove

            Form4 form = new Form4();
            form.Show();
            this.Close();

        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form2 form = new Form2();
            form.Show();
            this.Close();
        }
    }
}
