﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace ATM_Management_System
{
    public partial class Form2 : Form
    {
        MySqlConnection conn = new MySqlConnection("datasource=localhost; port=3306; username=root; password=bilal");
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("Select Name from atm.data Where ID = '" + Form1.gval + "';", conn);
            MySqlDataReader dr = cmd.ExecuteReader();
            while (dr.Read())
            {
                user.Text = dr.GetValue(0).ToString();
            }
            conn.Close();
        }        
        private void button1_Click_1(object sender, EventArgs e)
        {
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM atm.data WHERE (PIN = '" + t1.Text + "') And ID = '"+Form1.gval+"'", conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataSet checkid = new DataSet();
            adp.Fill(checkid);
            int i = checkid.Tables[0].Rows.Count;
            if (i > 0)
            {
                Form3 form3 = new Form3();
                form3.Show();
                this.Close();
            }
            else if (t1.Text == "")
            {
                l1.Text = "Please ENTER your PIN";
            }
            else
            {
                l1.Text = "Incorrect Pin Code. Try again?";
                t1.Text = "";
            }
            conn.Close();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            t1.Text = "";
            l1.Text = "Enter your 4-digit PIN code";
        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnclick(object sender, EventArgs e)
        {
            Button button = (Button)sender;
            int x = int.Parse(button.Text);
            t1.Text = t1.Text + x;
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void user_Click(object sender, EventArgs e)
        {
            
        }
    }
}
