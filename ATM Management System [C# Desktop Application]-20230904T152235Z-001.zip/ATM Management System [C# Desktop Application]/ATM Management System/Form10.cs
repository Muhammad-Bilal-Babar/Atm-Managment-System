﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ATM_Management_System
{
    public partial class Form10 : Form
    {
        MySqlConnection conn = new MySqlConnection("datasource=localhost; port=3306; username=root; password=bilal");
        public Form10()
        {
            InitializeComponent();
        }

        private void Form10_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlCommand cmd = new MySqlCommand("insert into atm.data(ID,Name,PIN,Type,Balance) Values('"+t1.Text+ "','" + t2.Text + "','" + t3.Text + "','" + t4.Text + "','" + t5.Text + "')", conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            MessageBox.Show("Account Created");
            conn.Close();
            t1.Text = "";
            t2.Text = "";
            t3.Text = "";
            t4.Text = "";
            t5.Text = "";
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void t2_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
