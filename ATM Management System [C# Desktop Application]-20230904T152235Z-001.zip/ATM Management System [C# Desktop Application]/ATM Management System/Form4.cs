﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace ATM_Management_System
{
    public partial class Form4 : Form
    {
        public static string amount = "NIL";
        MySqlConnection conn = new MySqlConnection("datasource=localhost; port=3306; username=root; password=bilal");
        public Form4()
        {
            InitializeComponent();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            string sql = "select * from atm.data; update atm.data SET balance = balance - 10000 where id = '" + Form1.gval + "'; ";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            Form5 form = new Form5();
            form.Show();
            MessageBox.Show("Amount Withdrawn");
            amount = "10000";
            this.Close();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            string sql = "select * from atm.data; update atm.data SET balance = balance - 1000 where id = '" + Form1.gval + "'; ";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            Form5 form = new Form5();  
            form.Show();
            MessageBox.Show("Amount Withdrawn");
            amount = "1000";
            this.Close();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string sql = "select * from atm.data; update atm.data SET balance = balance - 2000 where id = '" + Form1.gval + "'; ";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            Form5 form = new Form5();
            form.Show();
            MessageBox.Show("Amount Withdrawn");
            amount = "2000";
            this.Close();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            string sql = "select * from atm.data; update atm.data SET balance = balance - 5000 where id = '" + Form1.gval + "'; ";
            MySqlCommand cmd = new MySqlCommand(sql, conn);
            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();
            Form5 form = new Form5();
            form.Show();
            MessageBox.Show("Amount Withdrawn");
            amount = "5000";
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form9 form = new Form9();
            form.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 form = new Form8();
            form.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form7 form = new Form7();
            form.Show();
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form6 form = new Form6();
            form.Show();
            this.Close();
        }

        private void Form4_Load(object sender, EventArgs e)
        {

        }

        private void button9_Click(object sender, EventArgs e)
        {
            Form3 form = new Form3();
            form.Show();
            this.Close();
        }
    }
}
