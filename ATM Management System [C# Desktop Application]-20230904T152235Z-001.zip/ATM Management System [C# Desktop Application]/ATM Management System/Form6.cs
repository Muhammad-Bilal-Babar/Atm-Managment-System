﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
namespace ATM_Management_System
{
    public partial class Form6 : Form
    {
        
        public Form6()
        {
            InitializeComponent();
        }

        private void date_Click(object sender, EventArgs e)
        {

        }

        private void time_Click(object sender, EventArgs e)
        {

        }

        private void Form6_Load(object sender, EventArgs e)
        {
            date.Text = DateTime.Now.ToString();
            l1.Text = Form1.gval;
            l3.Text = Form4.amount;
            MySqlConnection conn = new MySqlConnection("datasource=localhost; port=3306; username=root; password=bilal");
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("Select Name from atm.data Where ID = '" + Form1.gval + "';", conn);
            MySqlDataReader dr = cmd.ExecuteReader();
            while(dr.Read())
            {
                l2.Text = dr.GetValue(0).ToString();
            }
            dr.Close();
            MySqlCommand cmd2 = new MySqlCommand("Select Balance from atm.data Where ID = '" + Form1.gval + "';", conn);
            MySqlDataReader dr2 = cmd2.ExecuteReader();
            while (dr2.Read())
            {
                l4.Text = dr2.GetValue(0).ToString();
            }
            dr2.Close();
            MySqlCommand cmd3 = new MySqlCommand("Select Balance from atm.data Where ID = '" + Form1.gval + "';", conn);
            MySqlDataReader dr3 = cmd3.ExecuteReader();
            while (dr3.Read())
            {
                l5.Text = dr3.GetValue(0).ToString();
            }
            dr3.Close();

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label15_Click(object sender, EventArgs e)
        {
           
        }
    }
}
