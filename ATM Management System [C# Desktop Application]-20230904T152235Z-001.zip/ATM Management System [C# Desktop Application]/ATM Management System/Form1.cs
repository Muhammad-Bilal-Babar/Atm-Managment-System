﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ATM_Management_System
{
    public partial class Form1 : Form
    {
        public static string gval= "";
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("datasource=localhost; port=3306; username=root; password=bilal");
            conn.Open();
            MySqlCommand cmd = new MySqlCommand("SELECT * FROM atm.data WHERE (ID = '" + t1.Text + "') ", conn);
            MySqlDataAdapter adp = new MySqlDataAdapter(cmd);
            DataSet checkid = new DataSet();
            adp.Fill(checkid);
            int i = checkid.Tables[0].Rows.Count;
            if (i > 0)
            {
                Form2 form2 = new Form2();
                form2.Show();
            }
            else
            {
                MessageBox.Show("Account Does Not Exist");
                t1.Text = "";
            }                
            conn.Close();
            gval = t1.Text;
            t1.Text = "";
            
        }

        private void l1_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form10 form10 = new Form10();  
            form10.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form11 form11 = new Form11();
            form11.Show();
        }

        private void t1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            Form12 form12 = new Form12();
            form12.Show();
        }
    }
}
